jQuery(document).ready(function($){
$('.main-menu').slicknav({
    label:init_vars.label
 });
});