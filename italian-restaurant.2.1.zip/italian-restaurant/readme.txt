-----------------------------------------------
License:
-----------------------------------------------

Italian Restaurant, Copyright 2014 WordPress.org
Italian Restaurant is distributed under the terms of the GNU GPL-2.0+

-----------------------------------------------
Scripts
-----------------------------------------------
All scripts in Italian Restaurant Theme are licenced under the terms of the GNU GPL with the exception of Twitter Bootstrap boilerplate, which is distributed under the MIT Licence.

WP Bootstrap Navwalker by Edward McIntyre is licensed under the terms of GPL-2.0+.

SlickNav jQuery Plugin by ComputerWolf is licenced under MIT Licence.

HTML5 Shiv v3.7.0 | @afarkas @jdalton @jon_neal @rem | MIT/GPL2 Licensed
-----------------------------------------------
Images
-----------------------------------------------
http://pixabay.com/en/cheese-crust-delicious-dinner-eat-164872/ - Public Domain CC0
http://pixabay.com/en/pizza-food-dinner-menu-200129/ - Public Domain CC0
http://pixabay.com/en/pizza-pie-toppings-sauce-cheese-13790/ - Public Domain CC0
http://pixabay.com/en/cheese-crust-delicious-dinner-eat-164872/ - Public Domain CC0
http://pixabay.com/en/spaghetti-pasta-italian-food-bacon-237907/ - Public Domain CC0

All images and logos in Italian Restaurant are our own creation and are licensed under the terms of the GNU GPL-2.0+.

-----------------------------------------------
Fonts
-----------------------------------------------
All fonts in Italian Restaurant theme are under the SIL Open Font License

License for GLYPHICONS Halflings in Twitter Bootstrap
GLYPHICONS Halflings are also a part of Bootstrap from Twitter, and they are released under the same license as Bootstrap.

-----------------------------------------------
Limitations
-----------------------------------------------
The Italian Restaurant Theme has a three level menu.

-----------------------------------------------
Change Log:
-----------------------------------------------

= 2.0 =
CSS Rewrites, New admin options included

= 2.1 =
Changed licence.txt


