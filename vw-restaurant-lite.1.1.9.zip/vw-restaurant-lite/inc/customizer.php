<?php
/**
 * VW Restaurant Lite Theme Customizer
 *
 * @package VW Restaurant Lite
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function vw_restaurant_lite_customize_register( $wp_customize ) {	

	//add home page setting pannel
	$wp_customize->add_panel( 'vw_restaurant_lite_panel_id', array(
	    'priority' => 10,
	    'capability' => 'edit_theme_options',
	    'theme_supports' => '',
	    'title' => __( 'VW Settings', 'vw-restaurant-lite' ),
	    'description' => __( 'Description of what this panel does.', 'vw-restaurant-lite' ),
	) );



	//home page slider
	$wp_customize->add_section( 'vw_restaurant_lite_slidersettings' , array(
    	'title'      => __( 'Slider Settings', 'vw-restaurant-lite' ),
		'priority'   => 30,
		'panel' => 'vw_restaurant_lite_panel_id'
	) );

	for ( $count = 1; $count <= 4; $count++ ) {

		// Add color scheme setting and control.
		$wp_customize->add_setting( 'vw_restaurant_lite_slidersettings-page-' . $count, array(
			'default'           => '',
			'sanitize_callback' => 'absint'
		) );

		$wp_customize->add_control( 'vw_restaurant_lite_slidersettings-page-' . $count, array(
			'label'    => __( 'Select Slide Image Page', 'vw-restaurant-lite' ),
			'section'  => 'vw_restaurant_lite_slidersettings',
			'type'     => 'dropdown-pages'
		) );

	}

	/*Contact Us*/
	$wp_customize->add_section('vw_restaurant_lite_contact_us',array(
		'title'	=> __('Contact Us','vw-restaurant-lite'),
		'description'	=> __('Add homepage sections content here.','vw-restaurant-lite'),
		'panel' => 'vw_restaurant_lite_panel_id'
	));
	
	$wp_customize->add_setting('vw_restaurant_lite_our_address',array(
		'default'	=> '',
		'sanitize_callback'	=> 'wp_kses_post'
	));
	
	$wp_customize->add_control('vw_restaurant_lite_our_address',array(
		'label'	=> __('Add Address here.','vw-restaurant-lite'),
		'section'	=> 'vw_restaurant_lite_contact_us',
		'setting'	=> 'vw_restaurant_lite_our_address',
		'type'		=> 'textarea'
	));
	$wp_customize->add_setting('vw_restaurant_lite_contact',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('vw_restaurant_lite_contact',array(
		'label'	=> __('Add Number here.','vw-restaurant-lite'),
		'section'	=> 'vw_restaurant_lite_contact_us',
		'setting'	=> 'vw_restaurant_lite_contact',
		'type'		=> 'text'
	));

	$wp_customize->add_setting('vw_restaurant_lite_email',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('vw_restaurant_lite_email',array(
		'label'	=> __('Add Email address here.','vw-restaurant-lite'),
		'section'	=> 'vw_restaurant_lite_contact_us',
		'setting'	=> 'vw_restaurant_lite_email',
		'type'		=> 'text'
	));
	
	$wp_customize->add_section('vw_restaurant_lite_footer_section',array(
		'title'	=> __('Footer Text','vw-restaurant-lite'),
		'description'	=> __('Add some text for footer like copyright etc.','vw-restaurant-lite'),
		'panel' => 'vw_restaurant_lite_panel_id'
	));
	
	$wp_customize->add_setting('vw_restaurant_lite_footer_copy',array(
		'default'	=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	
	$wp_customize->add_control('vw_restaurant_lite_footer_copy',array(
		'label'	=> __('Copyright Text','vw-restaurant-lite'),
		'section'	=> 'vw_restaurant_lite_footer_section',
		'type'		=> 'text'
	));
	
}
add_action( 'customize_register', 'vw_restaurant_lite_customize_register' );	

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function vw_restaurant_lite_customize_preview_js() {
	wp_enqueue_script( 'vw_restaurant_lite_customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20130508', true );
}
add_action( 'customize_preview_init', 'vw_restaurant_lite_customize_preview_js' );


/**
 * Singleton class for handling the theme's customizer integration.
 *
 * @since  1.0.0
 * @access public
 */
final class vw_restaurant_lite_customize {

	/**
	 * Returns the instance.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return object
	 */
	public static function get_instance() {

		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self;
			$instance->setup_actions();
		}

		return $instance;
	}

	/**
	 * Constructor method.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function __construct() {}

	/**
	 * Sets up initial actions.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function setup_actions() {

		// Register panels, sections, settings, controls, and partials.
		add_action( 'customize_register', array( $this, 'sections' ) );

		// Register scripts and styles for the controls.
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_control_scripts' ), 0 );
	}

	/**
	 * Sets up the customizer sections.
	 *
	 * @since  1.0.0
	 * @access public
	 * @param  object  $manager
	 * @return void
	 */
	public function sections( $manager ) {

		// Load custom sections.
		require_once( trailingslashit( get_template_directory() ) . '/inc/section-pro.php' );

		// Register custom section types.
		$manager->register_section_type( 'vw_restaurant_lite_customize_Section_Pro' );

		// Register sections.
		$manager->add_section(
			new vw_restaurant_lite_customize_Section_Pro(
				$manager,
				'example_1',
				array(
					'title'    => esc_html__( 'VW Restaurant Pro', 'vw-restaurant-lite' ),
					'pro_text' => esc_html__( 'Go Pro',         'vw-restaurant-lite' ),
					'pro_url'  => 'http://www.vwthemes.com/product/vw-restaurant-theme/'
				)
			)
		);
	}

	/**
	 * Loads theme customizer CSS.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return void
	 */
	public function enqueue_control_scripts() {

		wp_enqueue_script( 'vw-restaurant-lite-customize-controls', trailingslashit( get_template_directory_uri() ) . '/js/customize-controls.js', array( 'customize-controls' ) );

		wp_enqueue_style( 'vw-restaurant-lite-customize-controls', trailingslashit( get_template_directory_uri() ) . '/css/customize-controls.css' );
	}
}

// Doing this customizer thang!
vw_restaurant_lite_customize::get_instance();