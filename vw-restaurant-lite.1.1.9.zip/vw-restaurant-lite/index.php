<?php
/**
 * The template for displaying home page.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package VW Restaurant Lite
 */

get_header(); 
?>

  <?php /** slider section **/ ?>
  <div class="slider-main">
    <?php
      // Get pages set in the customizer (if any)
      $pages = array();
      for ( $count = 1; $count <= 5; $count++ ) {
        $mod = intval( get_theme_mod( 'vw_restaurant_lite_slidersettings-page-' . $count ) );
        if ( 'page-none-selected' != $mod ) {
          $pages[] = $mod;
        }
      }
      
      if( !empty($pages) ) :
        $args = array(
          'posts_per_page' => 5,
          'post_type' => 'page',
          'post__in' => $pages,
          'orderby' => 'post__in'
        );
        $query = new WP_Query( $args );
        if ( $query->have_posts() ) :
          $count = 1;
          ?>
          <div id="slider" class="nivoSlider">
            <?php
              $vw_restaurant_lite_n = 0;
            while ( $query->have_posts() ) : $query->the_post();
                
                $vw_restaurant_lite_n++;
                $vw_restaurant_lite_slideno[] = $vw_restaurant_lite_n;
                $vw_restaurant_lite_slidetitle[] = get_the_title();
                $vw_restaurant_lite_slidelink[] = esc_url( get_permalink() );
                ?>
                  <img src="<?php the_post_thumbnail_url('full'); ?>" title="#slidecaption<?php echo esc_attr( $vw_restaurant_lite_n ); ?>" />
                <?php
              $count++;
            endwhile;
            ?>
          </div>

          <?php
          $vw_restaurant_lite_k = 0;
            foreach( $vw_restaurant_lite_slideno as $vw_restaurant_lite_sln ){ ?>
              <div id="slidecaption<?php echo esc_attr( $vw_restaurant_lite_sln ); ?>" class="nivo-html-caption">
                <div class="slide-cap  ">
                  <div class="container">
                    <h2><?php echo esc_html( $vw_restaurant_lite_slidetitle[$vw_restaurant_lite_k] ); ?></h2>
                    <a class="read-more" href="<?php echo esc_url( $vw_restaurant_lite_slidelink[$vw_restaurant_lite_k] ); ?>"><?php _e( 'Learn More','vw-restaurant-lite' ); ?></a>
                  </div>
                </div>
              </div>
              <?php $vw_restaurant_lite_k++;
          }
          wp_reset_postdata();
        else : ?>
            <div class="header-no-slider"></div>
          <?php
        endif;
      else : ?>
          <div class="header-no-slider"></div>
      <?php
      endif; 
    ?>
  </div>

  <?php /** post section **/ ?>
  <section id="our-services" class="services flipInX">
                
      <?php if ( have_posts() ) :
        /* Start the Loop */
          
          while ( have_posts() ) : the_post();

            get_template_part( 'template-parts/content' ); 
          
          endwhile;

          else :

            get_template_part( 'no-results', 'archive' ); 

          endif; 
      ?>
      <div class="navigation">
        <?php
            // Previous/next page navigation.
            the_posts_pagination( array(
                'prev_text'          => __( 'Previous page', 'vw-restaurant-lite' ),
                'next_text'          => __( 'Next page', 'vw-restaurant-lite' ),
                'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'vw-restaurant-lite' ) . ' </span>',
            ) );
        ?>
          <div class="clearfix"></div>
      </div>
  </section>
<?php get_footer(); ?>