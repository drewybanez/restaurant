<?php
/**
 * The template part for displaying slider
 *
 * @package VW Restaurant Lite 
 * @subpackage vw_restaurant_lite
 * @since VW Restaurant Lite 1.0
 */
?>
  <div id="post-<?php the_ID(); ?>" <?php post_class('col-md-3 col-sm-6 col-xs-12 inner-service'); ?>>
    
    <h3 class="section-title col-sm-12"><a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php the_title_attribute(); ?>"><?php the_title();?></a></h3>
    <div class="box-image">
      <?php 
        if(has_post_thumbnail()) { 
          the_post_thumbnail(); 
        }
      ?>
    </div>
    <div class="new-text">
      <?php the_excerpt();?>
    </div>
    <div class="clearfix"></div>     

    <div class="wow bounceInUp">
      <a class="button hvr-sweep-to-right"  href="<?php echo esc_url( get_permalink() ); ?>" title="<?php _e( 'Read Full', 'vw-restaurant-lite' ); ?>"><?php _e('Read More','vw-restaurant-lite'); ?></a>
    </div> 
  </div>